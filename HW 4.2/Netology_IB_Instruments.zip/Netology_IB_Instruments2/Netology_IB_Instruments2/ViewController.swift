//
//  ViewController.swift
//  Netology_IB_Instruments2
//
//  Created by Simon Pegg on 13.07.2021.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

